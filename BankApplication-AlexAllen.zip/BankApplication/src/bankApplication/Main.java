package bankApplication;

public class Main {

	public static void main(String[] args) {
		//Run the swt window
		bankApplication.BankAppWindow.main(args);
	}

}
