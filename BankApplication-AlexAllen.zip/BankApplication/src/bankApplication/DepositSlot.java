package bankApplication;

public class DepositSlot {
	//Fields for desposit slot
	private int timeOutSeconds;
	private Boolean envolopeInserted;
	private Boolean confirmDeposit;
	
	//Constructor for a deposit slot
	public DepositSlot() {
		timeOutSeconds = 120;
		envolopeInserted = false;
		confirmDeposit = false;
	}
	
	//Getters for the fields
	public int getTimeout() {
		return timeOutSeconds;
	}
	
	public Boolean getInserted() {
		return envolopeInserted;
	}
	
	public Boolean getConfirmDeposit() {
		return confirmDeposit;
	}
	
	//Setter for confirmation
	public void setConfirmDeposit(Boolean value) {
		confirmDeposit = value;
	}
	
	//Setter for envelope inserted
	public void setEnvelopeInserted(Boolean value) {
		envolopeInserted = value;
	}
}
