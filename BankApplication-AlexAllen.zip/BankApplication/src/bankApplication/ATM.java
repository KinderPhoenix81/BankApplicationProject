package bankApplication;

public class ATM {
	//Fields of the atm
	private String atmStatus;
	private int currentAccountNum;
	private CashDispenser cashDispenser;
	private DepositSlot depositSlot;
	
	//Constructor for atm
	public ATM(String status, int num) {
		atmStatus = status;
		currentAccountNum = num;
		cashDispenser = new CashDispenser();
		depositSlot = new DepositSlot();
	}
	
	//Getters
	public String getStatus() {
		return atmStatus;
	}
	
	public int getAccountNum() {
		return currentAccountNum;
	}
	
	public CashDispenser getCashDispenser() {
		return cashDispenser;
	}
	
	public DepositSlot getDepositSlot() {
		return depositSlot;
	}
	
	//Setter for the atm status
	public void setStatus(String status) {
		//Reassign atmStatus
		atmStatus = status;
	}
	
	//Setter for atm account
	public void setNum(int num) {
		currentAccountNum = num;
	}

}
