package bankApplication;

public class Account {
	//Fields of an account
	private int accountNumber;
	private int accountPIN;
	private double accountBalance;
	private String accountHolder;
	private String accountType;
	
	//Constructor for an account
	public Account(int number, int pin, double balance, String name, String type) {
		accountNumber = number;
		accountPIN = pin;
		accountBalance = balance;
		accountHolder = name;
		accountType = type;
	}
	
	//Blank constructor
	public Account() {
		
	}
	
	//Getters for account variables
	public int getAccountNumber() {
		return accountNumber;
	}
	
	public int getAccountPIN() {
		return accountPIN;
	}
	
	public double getBalance() {
		return accountBalance;
	}
	
	public String getName() {
		return accountHolder;
	}
	
	public String getType() {
		return accountType;
	}
	
	//Setter for all values
	public void setValues(int number, int pin, double balance, String name, String type) {
		accountNumber = number;
		accountPIN = pin;
		accountBalance = balance;
		accountHolder = name;
		accountType = type;
	}
	
	public void setBalance(double balance) {
		accountBalance = balance;
	}
}
