package bankApplication;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Composite;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;

public class BankAppWindow {

	protected Shell shlAtmSimulation;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			BankAppWindow window = new BankAppWindow();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents(display);
		shlAtmSimulation.open();
		shlAtmSimulation.layout();
		while (!shlAtmSimulation.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents(Display display) {
		shlAtmSimulation = new Shell();
		shlAtmSimulation.setMinimumSize(new Point(600, 500));
		shlAtmSimulation.setSize(576, 500);
		shlAtmSimulation.setText("ATM Simulation");
		
		//Create a banking network
		BankingNetwork network = new BankingNetwork("Sample Systems", 101);
		
		//Creating an atm object
		ATM atm = new ATM("WaitForAccNo", 99999);
		
		//Composite for atm screen
		Composite atmScreenComposite = new Composite(shlAtmSimulation, SWT.BORDER);
		atmScreenComposite.setBounds(10, 10, 300, 300);
		
		Label currentInput = new Label(atmScreenComposite, SWT.BORDER | SWT.CENTER);
		currentInput.setBounds(110, 270, 80, 20);
		
		Label atmPromptLabel = new Label(atmScreenComposite, SWT.WRAP);
		atmPromptLabel.setAlignment(SWT.CENTER);
		atmPromptLabel.setBounds(10, 10, 276, 75);
		atmPromptLabel.setText("Welcome! Please input your five digit account number to begin.");
		
		Label displayUserInput = new Label(atmScreenComposite, SWT.BORDER);
		displayUserInput.setBackground(Display.getCurrent().getSystemColor(SWT.COLOR_GRAY));
		displayUserInput.setBounds(70, 244, 160, 20);
		
		Label contentLabel = new Label(atmScreenComposite, SWT.NONE);
		contentLabel.setBounds(24, 189, 252, 50);
		
		Composite keypadComposite = new Composite(shlAtmSimulation, SWT.NONE);
		keypadComposite.setBounds(150, 316, 160, 135);
		
		Button button = new Button(keypadComposite, SWT.NONE);
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				//Add the value of the button to the input text on screen
				NumpadKeypress(1, currentInput, shlAtmSimulation);
			}
		});
		button.setBounds(37, 10, 25, 25);
		button.setText("1");
		
		Button button_1 = new Button(keypadComposite, SWT.NONE);
		button_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				//Add the value of the button to the input text on screen
				NumpadKeypress(2, currentInput, shlAtmSimulation);
			}
		});
		button_1.setText("2");
		button_1.setBounds(68, 10, 25, 25);
		
		Button button_2 = new Button(keypadComposite, SWT.NONE);
		button_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				//Add the value of the button to the input text on screen
				NumpadKeypress(3, currentInput, shlAtmSimulation);
			}
		});
		button_2.setText("3");
		button_2.setBounds(99, 10, 25, 25);
		
		Button button_3 = new Button(keypadComposite, SWT.NONE);
		button_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				//Add the value of the button to the input text on screen
				NumpadKeypress(4, currentInput, shlAtmSimulation);
			}
		});
		button_3.setText("4");
		button_3.setBounds(37, 41, 25, 25);
		
		Button button_4 = new Button(keypadComposite, SWT.NONE);
		button_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				//Add the value of the button to the input text on screen
				NumpadKeypress(5, currentInput, shlAtmSimulation);
			}
		});
		button_4.setText("5");
		button_4.setBounds(68, 41, 25, 25);
		
		Button button_5 = new Button(keypadComposite, SWT.NONE);
		button_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				//Add the value of the button to the input text on screen
				NumpadKeypress(6, currentInput, shlAtmSimulation);
			}
		});
		button_5.setText("6");
		button_5.setBounds(99, 41, 25, 25);
		
		Button button_6 = new Button(keypadComposite, SWT.NONE);
		button_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				//Add the value of the button to the input text on screen
				NumpadKeypress(7, currentInput, shlAtmSimulation);
			}
		});
		button_6.setText("7");
		button_6.setBounds(37, 72, 25, 25);
		
		Button button_7 = new Button(keypadComposite, SWT.NONE);
		button_7.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				//Add the value of the button to the input text on screen
				NumpadKeypress(8, currentInput, shlAtmSimulation);
			}
		});
		button_7.setText("8");
		button_7.setBounds(68, 72, 25, 25);
		
		Button button_8 = new Button(keypadComposite, SWT.NONE);
		button_8.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				//Add the value of the button to the input text on screen
				NumpadKeypress(9, currentInput, shlAtmSimulation);
			}
		});
		button_8.setText("9");
		button_8.setBounds(99, 72, 25, 25);
		
		Button button_9 = new Button(keypadComposite, SWT.NONE);
		button_9.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				//Add the value of the button to the input text on screen
				NumpadKeypress(0, currentInput, shlAtmSimulation);
			}
		});
		button_9.setText("0");
		button_9.setBounds(68, 103, 25, 25);
		
		Button btnCashDispenser = new Button(shlAtmSimulation, SWT.WRAP);
		btnCashDispenser.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				//Remove cash
				btnCashDispenser.setText("Cash Dispenser");
				
				//Display a message
				MessageBox message = new MessageBox(shlAtmSimulation, SWT.NONE);
				message.setText("Notice");
				message.setMessage("Cash taken from dispenser.");
				message.open();
				
			}
		});
		btnCashDispenser.setBounds(10, 316, 134, 50);
		btnCashDispenser.setText("Cash Dispenser");
		
		Button btnDepositSlot = new Button(shlAtmSimulation, SWT.WRAP);
		btnDepositSlot.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				//Only display information if the envelope was inserted upon reaching the correct deposit screen
				if(atm.getDepositSlot().getConfirmDeposit() == true) {
					//Insert envelope
					btnCashDispenser.setText("Deposit Slot");
					
					//Set the boolean of the atm deposit slot
					atm.getDepositSlot().setEnvelopeInserted(true);
					
					//Display a message
					MessageBox message = new MessageBox(shlAtmSimulation, SWT.NONE);
					message.setText("Notice");
					message.setMessage("Envelope Inserted");
					message.open();
					
					//Set some display values
					atm.setStatus("Transaction");
					displayUserInput.setText("Deposit Successful!");
					atmPromptLabel.setText("Success! What would you like to do today?");
					contentLabel.setText("1- Balance\t2- Withdraw\n3- Deposit\t4- Exit");
				}
			}
		});
		btnDepositSlot.setText("Deposit Slot");
		btnDepositSlot.setBounds(10, 372, 134, 50);
		
		Button btnOk = new Button(keypadComposite, SWT.NONE);
		btnOk.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				//Create a new account
				Account account = new Account();
				
				//See if the current account number exists in memory and assign it to it's respective values
				for(Account acc : network.getAccounts()) {
					if(atm.getAccountNum() == acc.getAccountNumber()) {
						//Set values
						account.setValues(acc.getAccountNumber(), acc.getAccountPIN(), acc.getBalance(), acc.getName(), acc.getType());
					}
				}
				//Enter the input and run a command on the atm
				EnterInput(currentInput, displayUserInput, contentLabel, atmPromptLabel, btnCashDispenser, btnDepositSlot, shlAtmSimulation, display, atm, network.getAccounts(), account);
			}
		});
		btnOk.setText("OK");
		btnOk.setBounds(37, 103, 25, 25);
		
		Button buttonDelete = new Button(keypadComposite, SWT.NONE);
		buttonDelete.setText("DEL");
		buttonDelete.setBounds(99, 103, 25, 25);
		buttonDelete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				//Add the value of the button to the input text on screen
				NumpadKeypress(10, currentInput, shlAtmSimulation);
			}
		});
		
		Button btnClose = new Button(shlAtmSimulation, SWT.NONE);
		btnClose.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				//Close program
				shlAtmSimulation.dispose();
			}
		});
		btnClose.setBounds(499, 426, 75, 25);
		btnClose.setText("Close");
		
		Label lblNewLabel = new Label(shlAtmSimulation, SWT.NONE);
		lblNewLabel.setBounds(316, 10, 224, 15);
		lblNewLabel.setText("Welcome to the ATM Simulation Interface!");
		
		Label lblTheFollowingProgram = new Label(shlAtmSimulation, SWT.WRAP);
		lblTheFollowingProgram.setText("The following program is intended to mock the functionality of a genuine ATM, with the use of software in place of hardware.");
		lblTheFollowingProgram.setBounds(316, 31, 224, 61);
	}
	
	//Method to append data to the input value
	public void NumpadKeypress(int num, Label userInput, Shell shell) {
		//Parse the current data
		StringBuilder currentInput = new StringBuilder(userInput.getText());
		
		//Check to see if the user has reached the maximum character limit (11)
		if(currentInput.length() >= 12 && num != 10) {
			//Throw an messagebox
			MessageBox message = new MessageBox(shell, SWT.OK);
			message.setText("Maximum character limit reached");
			message.setMessage("Please enter in the current value to reset the user input.");
			message.open();
			
		} else if(num >= 0 && num <= 9){
			//Append the number
			currentInput.append(num);
			
			//Update the label
			userInput.setText(currentInput.toString());
		} else {
			//Only remove characters if there's any to begin with
			if(currentInput.length() >= 1) {
			//Backspace was clicked
			currentInput.deleteCharAt(currentInput.length() - 1);
				 
			//Update the label
			 userInput.setText(currentInput.toString());
			} 
		}
	}
	
	//Method to send the current input for a command
	public void EnterInput(Label userInput, Label display, Label content, Label prompt, Button dispenser, Button deposit, Shell shell, Display formDisplay, ATM atm, ArrayList<Account> accounts, Account account) {
		//If the user hasn't entered any numbers, show a message box
		if(userInput.getText().length() == 0) {
			//Show message
			MessageBox message = new MessageBox(shell, SWT.OK);
			message.setText("Invalid user input");
			message.setMessage("Please enter at least one value before proceeding.");
			message.open();
		} else {
			
			//Parse current info, will always be an integer
			int currentInput = Integer.parseInt(userInput.getText());
			
			//Execute a command with the input, return a new atm to update status and number
			ExecuteCommand(userInput, display, content, prompt, dispenser, deposit, formDisplay, atm, accounts, account);
			
			//Remove the contents of input
			userInput.setText("");
			
			//Debug
			System.out.println("Command Executed: " + currentInput);
		}
	}
	
	//Method to execute a command
	public void ExecuteCommand(Label userInput, Label display, Label content, Label prompt, Button dispenser, Button deposit, Display formDisplay, ATM atm , ArrayList<Account> accounts, Account account) {
		//Main method to perform actions
		
		//Parse values
		int input = Integer.parseInt(userInput.getText());
		
		//Boolean flags for actions
		Boolean actionPerformed = false;
		Boolean accountNumFound = false;
		
		//Reset alignments
		content.setAlignment(SWT.LEFT);
		
		//Bunch of conditionals to check the status of the ATM, then prompt different actions to the user
		//The user is on the deposit screen
		if(atm.getStatus().equals("Deposit") && actionPerformed == false) {
			//Set the envelope inserted to false by default
			atm.getDepositSlot().setEnvelopeInserted(false);
			
				//If the atm is not prompting a confirm on the deposit, get the value for dollar amount
				if(atm.getDepositSlot().getConfirmDeposit() == false) {
					//Perform the deposit
					double depositAmount = (double) input / 100;
					
					//Update labels
					prompt.setText("Confirm you want to make the deposit of $" + depositAmount + "?\nPress 0 to cancel deposit, press any other to perform deposit.");
					
					//Update flag
					atm.getDepositSlot().setConfirmDeposit(true);
				} else {
					//Confirmation has appeared, check for user input now
					if(input == 0) {
						//Revert screens, statuses, and labels
						atm.setStatus("Transaction");
						display.setText("Deposit Cancelled");
						prompt.setText("Success! What would you like to do today?");
						content.setText("1- Balance\t2- Withdraw\n3- Deposit\t4- Exit");
					} else {
						//Update button contents
						deposit.setText("Deposit Slot:\nInsert Envelope");
						prompt.setText("You're almost there! Please insert your envelope with the proper amount of cash into the deposit slot.\nTransaction will time out in 2 minutes.");
						content.setText("");
						
						//Implement timeout possibility
						formDisplay.timerExec(atm.getDepositSlot().getTimeout() * 1000, () -> {
							//If the envelope is not inserted in time
							if(!atm.getDepositSlot().getInserted()) {
							//Go back to the home screen
							atm.setStatus("Transaction");
							display.setText("Deposit Timed Out");
							prompt.setText("Success! What would you like to do today?");
							content.setText("1- Balance\t2- Withdraw\n3- Deposit\t4- Exit");
							}
						});
					}
				}
			
			//Update flag
			actionPerformed = true;
		}
		
		//The user is on the withdrawal screen, perform the withdraw
		if(atm.getStatus().equals("Withdrawal") && actionPerformed == false) {
			//Variables to store the amount withdrew & status, later used for database updating
			double withdrawAmount = 0;
			Boolean withdrawSuccess = false;
			
			//Set alignments
			content.setAlignment(SWT.CENTER);
			
			//Loop through the options below to perform an action
			if(input == 1) {
				//Withdraw 20 if the user has enough and the atm has enough
				if(atm.getCashDispenser().getBalance() >= 20 && account.getBalance() >= 20) {
					
					//Withdraw, update values
					atm.getCashDispenser().setBalance(atm.getCashDispenser().getBalance() - 20);
					account.setBalance(account.getBalance() - 20);
					
					//Set the withdrawal amount & status
					withdrawAmount = 20;
					withdrawSuccess = true;
				} else {
					//Prompt an error
					if(atm.getCashDispenser().getBalance() < 20) {
						//ATM funds are too low
						prompt.setText("Insufficient ATM funds, please enter another value, or notify network management.");
					} else {
						//Balance funds are too low
						prompt.setText("Insufficient account funds, please enter another value.");
					}
				}
			} else if(input == 2) {
				//Withdraw 40 if the user has enough and the atm has enough
				if(atm.getCashDispenser().getBalance() >= 40 && account.getBalance() >= 40) {
					
					//Withdraw, update values
					atm.getCashDispenser().setBalance(atm.getCashDispenser().getBalance() - 40);
					account.setBalance(account.getBalance() - 40);
					
					//Set the withdrawal amount & status
					withdrawAmount = 40;
					withdrawSuccess = true;
				} else {
					//Prompt an error
					if(atm.getCashDispenser().getBalance() < 40) {
						//ATM funds are too low
						prompt.setText("Insufficient ATM funds, please enter another value, or notify network management.");
					} else {
						//Balance funds are too low
						prompt.setText("Insufficient account funds, please enter another value.");
					}
				}
			} else if(input == 3) {
				//Withdraw 60 if the user has enough and the atm has enough
				if(atm.getCashDispenser().getBalance() >= 20 && account.getBalance() >= 60) {
					
					//Withdraw, update values
					atm.getCashDispenser().setBalance(atm.getCashDispenser().getBalance() - 60);
					account.setBalance(account.getBalance() - 60);
					
					//Set the withdrawal amount & status
					withdrawAmount = 60;
					withdrawSuccess = true;
				} else {
					//Prompt an error
					if(atm.getCashDispenser().getBalance() < 60) {
						//ATM funds are too low
						prompt.setText("Insufficient ATM funds, please enter another value, or notify network management.");
					} else {
						//Balance funds are too low
						prompt.setText("Insufficient account funds, please enter another value.");
					}
				}
			} else if(input == 4) {
				//Withdraw 100 if the user has enough and the atm has enough
				if(atm.getCashDispenser().getBalance() >= 100 && account.getBalance() >= 100) {
					
					//Withdraw, update values
					atm.getCashDispenser().setBalance(atm.getCashDispenser().getBalance() - 100);
					account.setBalance(account.getBalance() - 100);
					
					//Set the withdrawal amount & status
					withdrawAmount = 100;
					withdrawSuccess = true;
				} else {
					//Prompt an error
					if(atm.getCashDispenser().getBalance() < 100) {
						//ATM funds are too low
						prompt.setText("Insufficient ATM funds, please enter another value, or notify network management.");
					} else {
						//Balance funds are too low
						prompt.setText("Insufficient account funds, please enter another value.");
					}
				}
			} else if(input == 5) {
				//Withdraw 200 if the user has enough and the atm has enough
				if(atm.getCashDispenser().getBalance() >= 200 && account.getBalance() >= 200) {
					
					//Withdraw, update values
					atm.getCashDispenser().setBalance(atm.getCashDispenser().getBalance() - 200);
					account.setBalance(account.getBalance() - 200);
					
					//Set the withdrawal amount & status
					withdrawAmount = 200;
					withdrawSuccess = true;
				} else {
					//Prompt an error
					if(atm.getCashDispenser().getBalance() < 200) {
						//ATM funds are too low
						prompt.setText("Insufficient ATM funds, please enter another value, or notify network management.");
					} else {
						//Balance funds are too low
						prompt.setText("Insufficient account funds, please enter another value.");
					}
				}
			} else if(input == 6) {
				//Cancel the withdraw, set the screen back to the transaction screen
				atm.setStatus("Transaction");
				prompt.setText("Success! What would you like to do today?");
				display.setText("Welcome, " + account.getName());
				
				//Reset alignments
				content.setAlignment(SWT.LEFT);
				
				//Display options
				content.setText("1- Balance\t2- Withdraw\n3- Deposit\t4- Exit");
			} else {
				//Prompt an error
				prompt.setText("Unknown command, please enter a value from 1 to 6, and try again.");
			}
			
			//Update the account balance in the database if a withdraw occurred
			if(withdrawAmount > 0 && withdrawSuccess == true) {
				//Connection to database
				try {
					//Make a connection & sql statement
					Connection conn = DriverManager.getConnection("jdbc:sqlite:BankingInformation.db");
					String sql = "Update Accounts Set AccountBalance = ? Where AccountNumber = ?";
					
					//Make a prepared statement
					PreparedStatement inserter = conn.prepareStatement(sql);
					inserter.setDouble(1, account.getBalance());
					inserter.setInt(2, account.getAccountNumber());
					
					//Execute update
					inserter.executeUpdate();
					
					//Show success
					prompt.setText("Withdrawal successful, don't forget to take your cash from the dispenser!\nSelect an amount to withdraw.");
					dispenser.setText("Cash Dispenser\nCash Present: " + withdrawAmount);
					display.setText("Withdrew $" + withdrawAmount);
					
				} catch (SQLException e) {
					//Print stack trace
					e.printStackTrace();
				}
			}
			//Set flag
			actionPerformed = true;
		}
		
		//The user is on the balance screen and wants to return to the homepage
		if(atm.getStatus().equals("ViewingBalance") && actionPerformed == false) {

			//Update statuses & change label
			atm.setStatus("Transaction");
			prompt.setText("Success! What would you like to do today?");
			display.setText("Welcome, " + account.getName());
			
			//Display options
			content.setText("1- Balance\t2- Withdraw\n3- Deposit\t4- Exit");
			
			//Set flag
			actionPerformed = true;
		}
		
		//The user has logged in, check to see their input value and perform the appropriate action
		if(atm.getStatus().equals("Transaction") && actionPerformed == false) {
			
			//Reset alignments
			content.setAlignment(SWT.LEFT);
			
			//Check to see the value of transaction, and appropriately send the user to the right screen
			if(input == 1) {
				//Balance is to be shown
				double displayBalance = 0;
				
				//Fetch balance from database, to make sure it updates after a withdraw action
				try {
					//Connection & sql statement
					Connection conn = DriverManager.getConnection("jdbc:sqlite:BankingInformation.db");
					Statement statement = conn.createStatement();
					String sql = "Select AccountBalance From Accounts Where AccountNumber = " + account.getAccountNumber();
					
					//Create a result set
					ResultSet result = statement.executeQuery(sql);
					
					//Assing result to a variable
					while(result.next()) {
						displayBalance = result.getDouble("AccountBalance");
					}
					
				} catch (SQLException e) {
					//Print stack trace
					e.printStackTrace();
				}
				//Set prompt text
				prompt.setText("Below is the balance for the account " + account.getAccountNumber());
				
				//Set status
				atm.setStatus("ViewingBalance");
					
				//Display balance
				content.setAlignment(SWT.CENTER);
				content.setText("Your balance is: $" + (double) displayBalance + "\n(Select any value on the keypad to return to the transactions menu.)");
			} else if (input == 2) {
				//Withdraw process needs to occur
				prompt.setText("Select an amount to withdraw");
				
				//Display options
				content.setAlignment(SWT.CENTER);
				content.setText("1- $20\t2- $40\t3-$60\n4- $100\t5- $200\t6- Cancel");
				
				//Set status
				atm.setStatus("Withdrawal");
				
			} else if (input == 3) {
				//Deposit process occurs
				prompt.setText("Select an amount to deposit");
				
				//Add specification
				content.setAlignment(SWT.CENTER);
				content.setText("*Value entered is in cents, so 125 = $1.25.\nAfter entering in a value, select OK.");
				
				//Set status
				atm.setStatus("Deposit");
				
			} else if (input == 4){
				//Reset labels
				display.setText("User Disconnected");
				content.setText("");
				prompt.setText("Welcome! Please enter your five digit account number to begin.");

				//Close out of the transaction screen
				atm.setStatus("WaitForAccNo");
				atm.setNum(99999); 
				
				//Set flag
				actionPerformed = true;
			} else {
				prompt.setText("Unknown command, please try again, entering a value from 1 to 4.");
			}
		}
		
		//An account has been found, test to see if their pin matches
		if(atm.getStatus().equals("WaitForPin") && actionPerformed == false) {
			//See if the pin matches the account
			if(input == account.getAccountPIN()) {
				//Update statuses & change label
				atm.setStatus("Transaction");
				prompt.setText("Success! What would you like to do today?");
				display.setText("Welcome, " + account.getName());
				
				//Display options
				content.setText("1- Balance\t2- Withdraw\n3- Deposit\t4- Exit");
			} else {
			//Update label to display error and prompt another try
			prompt.setText("The PIN you entered was not correct, please try again.");
				}
			
			//Set flag
			actionPerformed = true;
			}
			
		
		//The user has input an account number, lets check to see if it matches a valid account number
		if(atm.getStatus().equals("WaitForAccNo") && actionPerformed == false) {
			//Loop through accounts to see if a value matches
			for(Account acc : accounts) {
				if(input == acc.getAccountNumber() && !accountNumFound) {
					//Success, change statuses
					atm.setNum(acc.getAccountNumber());
					atm.setStatus("WaitForPin");
					accountNumFound = true;
					//Change labels
					prompt.setText("Welcome, please enter your five-digit PIN.");
					display.setText("Account No: " + atm.getAccountNum());
					
					//Set flag
					actionPerformed = true;
				}
			}
			
			//Check to see if an account wasn't found
			if(!accountNumFound) {
				//Prompt user
				prompt.setText("There was no account number with that value, please try again, or another account number.");
			}
			//Set flag
			actionPerformed = true;
		}
			
	}
	
}

