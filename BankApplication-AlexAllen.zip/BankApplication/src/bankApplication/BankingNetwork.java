package bankApplication;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class BankingNetwork {
	//Fields for network
	private ArrayList<Account> accountList;
	private String networkName;
	private int networkID;
	
	//Constructor for a network object
	public BankingNetwork(String name, int id) {
		accountList = new ArrayList<Account>();
		networkName = name;
		networkID = id;
		
		//Populate the account list
		initializeAccounts(accountList);
	}
	
	//Method to populate the account list from the database
	private void initializeAccounts(ArrayList<Account> list) {
		//Try catch for sql issues
		try {
			//Make a connection
			Connection conn = DriverManager.getConnection("jdbc:sqlite:BankingInformation.db");
			
			//Make an sql string and statement
			String sql = "Select * From Accounts";
			Statement statement = conn.createStatement();
			
			//Make a result set
			ResultSet result = statement.executeQuery(sql);
			
			//Assign the values of the result set
			while(result.next()) {
				int number = result.getInt("AccountNumber");
				int pin = result.getInt("AccountPIN");
				String name = result.getString("AccountHolderName");
				Double balance = result.getDouble("AccountBalance");
				String type = result.getString("AccountType");
				
				//Create a new account
				Account account = new Account(number, pin, balance, name, type);
				
				//Add to the list
				list.add(account);
			}
			
		} catch (SQLException e) {
			//Print sql errors
			e.printStackTrace();
		}
		
		//Debug
		System.out.println("Number of Accounts: " + accountList.size());
	}
	
	//Getters for the network
	public ArrayList<Account> getAccounts() {
		return accountList;
	}
}
