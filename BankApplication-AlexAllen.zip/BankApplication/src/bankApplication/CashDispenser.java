package bankApplication;

public class CashDispenser {
	//Fields of the dispenser
	private double balance;
	
	//Constructor
	public CashDispenser() {
		balance = 10000;
	}
	
	//Getter for balance
	public double getBalance() {
		return balance;
	}
	
	//Setter for balance
	public void setBalance(double balance) {
		this.balance = balance;
	}
}
